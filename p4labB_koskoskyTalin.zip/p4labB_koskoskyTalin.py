#Talin koskosky

#1-3-24

#Writing intials with a new color in turtle
import turtle
wn = turtle.Screen()

tk = turtle.Turtle()


tk.color("purple")



tk.penup()#postion of "T"
tk.goto(-50,0)
tk.setheading(90)
tk.pendown()
tk.forward(50)

tk.backward(25)
tk.left(90)
tk.forward(50)
tk.right(90)
tk.penup()

tk.color("red")


tk.penup()
tk.goto(0, 0)# Position for "K"
tk.setheading(90)
tk.pendown()
tk.forward(50)
tk.backward(100)

tk.penup()
tk.goto(0,0)  
tk.setheading(-45)  
tk.pendown()
tk.forward(70)

tk.penup()
tk.goto(0,0)  
tk.setheading(45)  
tk.pendown()
tk.forward(70)
