#Talin koskosky

#11-3-24

#using a turtle to play games?

#import turtle into program
import turtle

#give it a play ground
wn = turtle.Screen()

#name the turtle
tk = turtle.Turtle()
for i in range(4):
    tk.forward(50)
    tk.left(90)
for i in range(1):
    tk.right(45)
    tk.forward(50)
    tk.left(45)
    tk.left(45)
    tk.left(24)
    tk.forward(48)
tk.color("purple")
tk.penup()
tk.goto(-50,0)
tk.pendown()
tk.right(50)
tk.left(25)


wn.mainloop() 


