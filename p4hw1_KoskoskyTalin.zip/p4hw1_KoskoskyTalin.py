#Talin Koskosky

#11-5-24
#--------------------------------------

#pseudocode:
#make a list
#have grades/ scores put in
#have it loop for a score 0-100 nothing more or less
#grade meets requierements: add, if not cut off and have new input placed
#calculate grade and letter grade

#--------------------------------------


#Adding onto p2hw2 to add letter grades.

# Talin Koskosky
# 10-11-24
# P2HW2
# Making a quick program to show avg grades plus more in class.
# list grades = []
grades = []  # Initialize the grades list

num_scores = int(input("Number of grades:"))

for i in range(num_scores):
    while True: #loop
        score = float(input(f"Enter grade {i + 1}: "))
        if 0 <= score <= 100:
            grades.append(score)
            break 
        else:
            print("invalid grade must be between 0-100")

lowest_score = min(grades)
print("Lowest grade:" , lowest_score)

grades_without_lowest = [grade for grade in grades if grade != lowest_score]

print("Grades after dropping lowest score:", grades_without_lowest)





# grades for modules
# grades.append adds the grade to list. 
grades.append(float(input("Enter grade for Module 1: ")))
grades.append(float(input("Enter grade for Module 2: ")))
grades.append(float(input("Enter grade for Module 3: ")))
grades.append(float(input("Enter grade for Module 4: ")))
grades.append(float(input("Enter grade for Module 5: ")))
grades.append(float(input("Enter grade for Module 6: ")))

# Calculate numbers
highest_grade = max(grades)
lowest_grade = min(grades)
sum_of_grades = sum(grades)
average_grade = sum_of_grades / len(grades)

# show results
print("-" * 34)
print("Lowest grade: ", lowest_grade)
print("Highest grade: ", highest_grade)
print("Sum of grades: ", sum_of_grades)
print("Average of grades:{:.2f}".format(average_grade))



if grades_without_lowest:
    average_grade = sum(grades_without_lowest) / len(grades_without_lowest)


           # Determine letter grade
    if average_grade >= 100:
        letter_grade = 'A'
    elif average_grade >= 90:
        letter_grade = 'B'
    elif average_grade >= 80:
        letter_grade = 'C'
    elif average_grade >= 70:
        letter_grade = 'D'
    elif average_grade <= 69:
        letter_grade = 'F'

        print("Letter grade for average:", letter_grade)
else:
        print("no grade avaliable")
print("-" * 34)

